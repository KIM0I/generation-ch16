package com.generation.fgm.demo_hola;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoHolaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoHolaApplication.class, args);
	}

}
